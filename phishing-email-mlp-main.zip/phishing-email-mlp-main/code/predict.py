import pickle
import torch
from sklearn.feature_extraction.text import TfidfVectorizer

vectorizer: TfidfVectorizer = pickle.load(open("../trained-models/151225_TfidfVectorizer.pickle", "rb"))
model = torch.load("../trained-models/151225_phishing_mlp.pt")


def predict(email_body) -> torch.Tensor:
    x = vectorizer.transform([email_body])
    x = torch.from_numpy(x.toarray().astype('float32'))
    return model.forward(x)


examples = [
    "Dear CEO, We are available at any time on Wednesday for the progress demo. However, our commitment to continuously learning and applying machine learning and AI. Best regards,",
    "Dear colleagues,Find attached Rwanda Works Government Newsletter 8 - 14 January 2024 for your information.\nRegards,\nPeter N.",
    "Once in a life time offer, specifically designed for you. Save up to 80% on your next purchase with our new online shop.",
    "URGENT! Your account will be deleted if you don't login to confirm your credentials. Act before it is too late.",
    "Congratulations! You have won our end of the year raffle! Your prizes are a new car, $10k and an all-expenses paid trip to a country of your choice.",
    "We've updated our login credential policy. Please confirm your account by logging into Google Docs.",
    """Let’s get to the finish line

NIYONGABO Aristide keep building your dreams!

Don’t let what you started here fizzle out. You came to Builderall with a goal in mind; let’s work together to achieve it!

You have a whole team to support your digital marketing journey and help you succeed.
    """,
    """

Hey there, 

We have some awesome news to share!! 🌟 The Builderall Dream Builder Awards are here, and we want you to be a part of it! 

This monthly recognition program is all about celebrating Builderall users who, like you, are using Builderall to build their dream businesses. Builderall wants to give you up to $5,000 to fuel your business, and all we need you to do is tell us your story! Here are all the details:

Entering is easy

Create a video (or post) telling us about:

Your business, and what it stands for.
Your journey as an entrepreneur, and what it has taught you. 
Why you are choosing Builderall to build and grow your business.
Be sure to mention Builderall @builderallofficial_, and use #DreamBuilder in the caption. 

Click here to get all the details on the Builderall Dream Builder Awards page.
    """,
    """Hello there,

Congratulations and welcome to our program as a Technical Mentor Volunteer! We are thrilled to have you on board and look forward to the valuable contributions you will make in supporting aspiring software engineers.

To get started, we invite you to join our dedicated Slack community, where you will engage with participants, answer their questions, and provide career guidance throughout the 8-week program. Link to our slack community.

We will be having a Kick-Off Call to provide an overview of the program, discuss expectations, and address any questions or concerns you may have. This call will be held on 8th June, and we have sent a calendar invite to your email with the details. Please check your inbox for the invite and confirm your availability.

Before we proceed further, We would like to restate that this position is a volunteer position meaning it's an unpaid opportunity. We are truly grateful for your willingness to volunteer your time and expertise. Your dedication as a Technical Mentor Volunteer will play a vital role in shaping the career paths of aspiring software engineers and making a lasting impact on their professional journeys.

If you have any questions, concerns or need further assistance, please don't hesitate to reach out to us. We are here to support you every step of the way.

Warm regards,
    """
]

for i in range(len(examples)):
    prediction = predict(examples[i])
    print(
        f"\n---\n{examples[i]}\n\t• Legitimate: {prediction[0, 0] * 100:0.2f}%\n\t• Phishing: {prediction[0, 1] * 100:0.2f}%")
