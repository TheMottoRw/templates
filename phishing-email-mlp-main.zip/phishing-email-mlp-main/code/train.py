import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import torch
from phishing_mlp import PhishingMLP
import pickle
from datetime import datetime

print("reading dataset...")
dataset = pd.read_csv("../datasets/combined.csv", header=None)
dataset = dataset.dropna()
dataset = dataset.to_numpy()

X = dataset[:, :-1]
y = dataset[:, -1]
y = y.astype('int')

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
# X_train = X_train[2000:, :]
# X_test = X_test[2000:, :]
# y_train = y_train[2000:]
# y_test = y_test[2000:]

print("preprocessing...")
vectorizer = TfidfVectorizer(analyzer='word', stop_words='english', max_features=20000)
X_train = vectorizer.fit_transform(X_train[:, 0]).toarray().astype('float32')
X_test = vectorizer.transform(X_test[:, 0]).toarray().astype('float32')

print("training...")
classifier = PhishingMLP(print_epoch_loss=True,
                         epoch_count=50,
                         batch_size=1000,
                         model_width=16,
                         weight_decay=10 ** -7,
                         lr=0.002)
classifier.fit(X_train, y_train)

print("testing...")
test_result = classifier.predict(torch.from_numpy(X_test))
test_result = torch.argmax(test_result, dim=1)
y_test = torch.argmax(torch.from_numpy(classifier.int_to_onehot(y_test, 2)), dim=1)
test_correct = torch.mean((test_result == y_test).float())
print(f"Test accuracy: {test_correct * 100:0.2f}%")

time = datetime.now().strftime("%H%M%S")
model_path = f"../trained-models/{time}_phishing_mlp.pt"
vectorizer_path = f"../trained-models/{time}_TfidfVectorizer.pickle"
pickle.dump(vectorizer, open(vectorizer_path, "wb"))
torch.save(classifier.model, model_path)
print("saved " + vectorizer_path)
print("saved " + model_path)

print("done.")
