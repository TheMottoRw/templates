import numpy as np
import torch
import torch.nn as nn
from numpy import ndarray
from sklearn.model_selection import train_test_split
from torch.utils.data import TensorDataset, DataLoader


class PhishingMLP:
    model = None

    def __init__(self, print_epoch_loss=False,
                 batch_size=100,
                 epoch_count=500,
                 lr=0.001,
                 model_width=6,
                 weight_decay=0):
        self.print_epoch_loss = print_epoch_loss
        self.batch_size = batch_size
        self.epoch_count = epoch_count
        self.lr = lr
        self.model_width = model_width
        self.weight_decay = weight_decay

    def int_to_onehot(self, y, num_labels):
        ary = np.zeros((y.shape[0], num_labels))
        for i, val in enumerate(y):
            ary[i, val] = 1
        return ary

    def __train(self, x_train, y_train, x_valid, y_valid):
        # Create a DataLoader for handling batches during training
        loader = DataLoader(TensorDataset(x_train, y_train), batch_size=self.batch_size)

        # Initialize the Adam optimizer with specified learning rate and weight decay
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        # Initialize the binary cross-entropy loss function
        loss_fn = nn.BCELoss()

        # Initialize variables for tracking loss and early stopping
        loss = 0
        prev_validation = 0
        decrease_thresh = 4
        decrease_current = decrease_thresh

        # Loop through epochs for training
        for epoch in range(1, self.epoch_count + 1):
            # Initialize variable to track correct predictions in the training set
            train_correct = 0

            # Iterate over batches in the DataLoader
            for x_batch, y_batch in loader:
                # Forward pass: compute predictions
                pred = self.model.forward(x_batch)

                # Compute binary cross-entropy loss
                loss = loss_fn(pred, y_batch)

                # Backward pass: compute gradients and update model parameters
                loss.backward()
                optimizer.step()

                # Zero the gradients for the next iteration
                optimizer.zero_grad()

                # Track correct predictions for training accuracy
                train_correct += (torch.argmax(pred, dim=1) == torch.argmax(y_batch, dim=1)).float().sum()

            # Calculate training accuracy as a percentage
            train_correct /= x_train.shape[0]

            # Compute predictions on the validation set
            valid_pred = self.model.forward(x_valid)

            # Calculate validation accuracy as a percentage
            valid_correct = (torch.argmax(valid_pred, dim=1) == torch.argmax(y_valid, dim=1)).float()
            valid_correct = torch.mean(valid_correct)

            # Print training progress if specified
            if self.print_epoch_loss:
                print(
                    f"{epoch:03d}: {loss:.4f} | Train set: {train_correct * 100:0.2f}% | Validation set: {valid_correct * 100:0.2f}%")

            # Early stopping: adjust 'decrease_current' based on validation accuracy trends
            if prev_validation > valid_correct:
                decrease_current = max(0, decrease_current - 1)
            elif prev_validation < valid_correct:
                decrease_current = min(decrease_thresh, decrease_current + 1)

            # Check if early stopping criterion is met
            if decrease_current == 0:
                print("Early end due to decreasing validation accuracy")
                break

            # Update the variable for the next iteration
            prev_validation = valid_correct

    def predict(self, x: torch.Tensor):
        return self.model.forward(x)

    def fit(self, x: ndarray, y: ndarray):
        # Convert integer labels to one-hot encoding
        y = np.array(self.int_to_onehot(y, 2), dtype='float32')

        # Split the data into training and validation sets
        x_train, x_valid, y_train, y_valid = train_test_split(x, y, test_size=0.3, stratify=y)

        # Convert data to PyTorch tensors
        x_train, x_valid, y_train, y_valid = \
            torch.from_numpy(x_train), torch.from_numpy(x_valid), torch.from_numpy(y_train), torch.from_numpy(y_valid)

        # Define the neural network model using PyTorch's Sequential
        self.model = nn.Sequential(
            # Input layer: Linear transformation with Tanh activation
            nn.Linear(in_features=x_train.shape[1], out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.Tanh(),

            # Hidden layers: Linear transformations with Tanh activation
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.Tanh(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.Tanh(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.Tanh(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),
            nn.Linear(in_features=self.model_width, out_features=self.model_width, bias=True, dtype=torch.float32),
            nn.GELU(),

            # Output layer: Linear transformation with softmax activation
            nn.Linear(in_features=self.model_width, out_features=2, bias=True, dtype=torch.float32),
            nn.Softmax(dim=1)
        )

        # Train the model using the private __train method
        self.__train(x_train, y_train, x_valid, y_valid)

